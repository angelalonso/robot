from .robotlogic import *

__doc__ = robotlogic.__doc__
if hasattr(robotlogic, "__all__"):
    __all__ = robotlogic.__all__